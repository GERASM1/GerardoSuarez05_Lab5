
function addItem(){

$("button").on('click',function(event){
        event.preventDefault();
        let item = $("#item").val(); 
        if (item != "") { 
        $("ul").append(`<div class = "divlist">   
        <li> ${item} </li>
        <button class = "check" type ="button" id ="checkb" > check </button>
        <button class = "delete" type = "button" id = "deleteb"> delete </button> 
        </div>`);
        }
});

$("ul").on('click', ".check",function(event){
    event.preventDefault();
   $(this).parent().css('text-decoration', 'line-through');
});

$("ul").on('click', ".delete", function(event){
    event.preventDefault();
    $(this).parent().remove();
})
}

addItem();